<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis minScale="75000" autoRefreshMode="Disabled" maxScale="0" labelsEnabled="0" simplifyDrawingHints="1" hasScaleBasedVisibilityFlag="1" version="3.44.8-Solothurn" autoRefreshTime="0" simplifyLocal="1" styleCategories="AllStyleCategories" simplifyDrawingTol="1" simplifyMaxScale="1" readOnly="0" symbologyReferenceScale="-1" simplifyAlgorithm="0">
 <flags>
  <Identifiable>1</Identifiable>
  <Removable>1</Removable>
  <Searchable>1</Searchable>
  <Private>0</Private>
 </flags>
 <elevation binding="Centroid" zoffset="0" zscale="1" clamping="Terrain" symbology="Line" extrusionEnabled="0" type="IndividualFeatures" customToleranceEnabled="0" extrusion="0" respectLayerSymbol="1" showMarkerSymbolInSurfacePlots="0">
  <data-defined-properties>
   <Option type="Map">
    <Option type="QString" name="name" value=""/>
    <Option name="properties"/>
    <Option type="QString" name="type" value="collection"/>
   </Option>
  </data-defined-properties>
  <profileLineSymbol>
   <symbol is_animated="0" frame_rate="10" type="line" alpha="1" clip_to_extent="1" force_rhr="0" name="">
    <data_defined_properties>
     <Option type="Map">
      <Option type="QString" name="name" value=""/>
      <Option name="properties"/>
      <Option type="QString" name="type" value="collection"/>
     </Option>
    </data_defined_properties>
    <layer enabled="1" pass="0" id="{0f334a4a-331c-48f9-a673-567747b2562f}" locked="0" class="SimpleLine">
     <Option type="Map">
      <Option type="QString" name="align_dash_pattern" value="0"/>
      <Option type="QString" name="capstyle" value="square"/>
      <Option type="QString" name="customdash" value="5;2"/>
      <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
      <Option type="QString" name="customdash_unit" value="MM"/>
      <Option type="QString" name="dash_pattern_offset" value="0"/>
      <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
      <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
      <Option type="QString" name="draw_inside_polygon" value="0"/>
      <Option type="QString" name="joinstyle" value="bevel"/>
      <Option type="QString" name="line_color" value="183,72,75,255,rgb:0.7176471,0.2823529,0.2941176,1"/>
      <Option type="QString" name="line_style" value="solid"/>
      <Option type="QString" name="line_width" value="0.6"/>
      <Option type="QString" name="line_width_unit" value="MM"/>
      <Option type="QString" name="offset" value="0"/>
      <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
      <Option type="QString" name="offset_unit" value="MM"/>
      <Option type="QString" name="ring_filter" value="0"/>
      <Option type="QString" name="trim_distance_end" value="0"/>
      <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
      <Option type="QString" name="trim_distance_end_unit" value="MM"/>
      <Option type="QString" name="trim_distance_start" value="0"/>
      <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
      <Option type="QString" name="trim_distance_start_unit" value="MM"/>
      <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
      <Option type="QString" name="use_custom_dash" value="0"/>
      <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
     </Option>
     <data_defined_properties>
      <Option type="Map">
       <Option type="QString" name="name" value=""/>
       <Option name="properties"/>
       <Option type="QString" name="type" value="collection"/>
      </Option>
     </data_defined_properties>
    </layer>
   </symbol>
  </profileLineSymbol>
  <profileFillSymbol>
   <symbol is_animated="0" frame_rate="10" type="fill" alpha="1" clip_to_extent="1" force_rhr="0" name="">
    <data_defined_properties>
     <Option type="Map">
      <Option type="QString" name="name" value=""/>
      <Option name="properties"/>
      <Option type="QString" name="type" value="collection"/>
     </Option>
    </data_defined_properties>
    <layer enabled="1" pass="0" id="{b026b2e8-a669-4866-8655-fe7ef2c3936f}" locked="0" class="SimpleFill">
     <Option type="Map">
      <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
      <Option type="QString" name="color" value="183,72,75,255,rgb:0.7176471,0.2823529,0.2941176,1"/>
      <Option type="QString" name="joinstyle" value="bevel"/>
      <Option type="QString" name="offset" value="0,0"/>
      <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
      <Option type="QString" name="offset_unit" value="MM"/>
      <Option type="QString" name="outline_color" value="131,51,54,255,rgb:0.5125963,0.2016785,0.210071,1"/>
      <Option type="QString" name="outline_style" value="solid"/>
      <Option type="QString" name="outline_width" value="0.2"/>
      <Option type="QString" name="outline_width_unit" value="MM"/>
      <Option type="QString" name="style" value="solid"/>
     </Option>
     <data_defined_properties>
      <Option type="Map">
       <Option type="QString" name="name" value=""/>
       <Option name="properties"/>
       <Option type="QString" name="type" value="collection"/>
      </Option>
     </data_defined_properties>
    </layer>
   </symbol>
  </profileFillSymbol>
  <profileMarkerSymbol>
   <symbol is_animated="0" frame_rate="10" type="marker" alpha="1" clip_to_extent="1" force_rhr="0" name="">
    <data_defined_properties>
     <Option type="Map">
      <Option type="QString" name="name" value=""/>
      <Option name="properties"/>
      <Option type="QString" name="type" value="collection"/>
     </Option>
    </data_defined_properties>
    <layer enabled="1" pass="0" id="{d062daeb-f8da-48da-954f-d534e9b7d28a}" locked="0" class="SimpleMarker">
     <Option type="Map">
      <Option type="QString" name="angle" value="0"/>
      <Option type="QString" name="cap_style" value="square"/>
      <Option type="QString" name="color" value="183,72,75,255,rgb:0.7176471,0.2823529,0.2941176,1"/>
      <Option type="QString" name="horizontal_anchor_point" value="1"/>
      <Option type="QString" name="joinstyle" value="bevel"/>
      <Option type="QString" name="name" value="diamond"/>
      <Option type="QString" name="offset" value="0,0"/>
      <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
      <Option type="QString" name="offset_unit" value="MM"/>
      <Option type="QString" name="outline_color" value="131,51,54,255,rgb:0.5125963,0.2016785,0.210071,1"/>
      <Option type="QString" name="outline_style" value="solid"/>
      <Option type="QString" name="outline_width" value="0.2"/>
      <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
      <Option type="QString" name="outline_width_unit" value="MM"/>
      <Option type="QString" name="scale_method" value="diameter"/>
      <Option type="QString" name="size" value="3"/>
      <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
      <Option type="QString" name="size_unit" value="MM"/>
      <Option type="QString" name="vertical_anchor_point" value="1"/>
     </Option>
     <data_defined_properties>
      <Option type="Map">
       <Option type="QString" name="name" value=""/>
       <Option name="properties"/>
       <Option type="QString" name="type" value="collection"/>
      </Option>
     </data_defined_properties>
    </layer>
   </symbol>
  </profileMarkerSymbol>
 </elevation>
 <renderer-v2 type="singleSymbol" enableorderby="0" referencescale="-1" forceraster="0" symbollevels="0">
  <symbols>
   <symbol is_animated="0" frame_rate="10" type="fill" alpha="1" clip_to_extent="1" force_rhr="0" name="0">
    <data_defined_properties>
     <Option type="Map">
      <Option type="QString" name="name" value=""/>
      <Option name="properties"/>
      <Option type="QString" name="type" value="collection"/>
     </Option>
    </data_defined_properties>
    <layer enabled="1" pass="0" id="{d8894e9c-f70d-4c76-a3e1-95bfccd5a065}" locked="0" class="SimpleFill">
     <Option type="Map">
      <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
      <Option type="QString" name="color" value="255,255,255,255,rgb:1,1,1,1"/>
      <Option type="QString" name="joinstyle" value="bevel"/>
      <Option type="QString" name="offset" value="0,0"/>
      <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
      <Option type="QString" name="offset_unit" value="MM"/>
      <Option type="QString" name="outline_color" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1"/>
      <Option type="QString" name="outline_style" value="solid"/>
      <Option type="QString" name="outline_width" value="0.125"/>
      <Option type="QString" name="outline_width_unit" value="MM"/>
      <Option type="QString" name="style" value="solid"/>
     </Option>
     <data_defined_properties>
      <Option type="Map">
       <Option type="QString" name="name" value=""/>
       <Option name="properties"/>
       <Option type="QString" name="type" value="collection"/>
      </Option>
     </data_defined_properties>
    </layer>
   </symbol>
  </symbols>
  <rotation/>
  <sizescale/>
  <data-defined-properties>
   <Option type="Map">
    <Option type="QString" name="name" value=""/>
    <Option name="properties"/>
    <Option type="QString" name="type" value="collection"/>
   </Option>
  </data-defined-properties>
 </renderer-v2>
 <selection mode="Default">
  <selectionColor invalid="1"/>
  <selectionSymbol>
   <symbol is_animated="0" frame_rate="10" type="fill" alpha="1" clip_to_extent="1" force_rhr="0" name="">
    <data_defined_properties>
     <Option type="Map">
      <Option type="QString" name="name" value=""/>
      <Option name="properties"/>
      <Option type="QString" name="type" value="collection"/>
     </Option>
    </data_defined_properties>
    <layer enabled="1" pass="0" id="{b20ccea3-17c0-44e6-97a3-5a1da2421fd1}" locked="0" class="SimpleFill">
     <Option type="Map">
      <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
      <Option type="QString" name="color" value="0,0,255,255,rgb:0,0,1,1"/>
      <Option type="QString" name="joinstyle" value="bevel"/>
      <Option type="QString" name="offset" value="0,0"/>
      <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
      <Option type="QString" name="offset_unit" value="MM"/>
      <Option type="QString" name="outline_color" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1"/>
      <Option type="QString" name="outline_style" value="solid"/>
      <Option type="QString" name="outline_width" value="0.26"/>
      <Option type="QString" name="outline_width_unit" value="MM"/>
      <Option type="QString" name="style" value="solid"/>
     </Option>
     <data_defined_properties>
      <Option type="Map">
       <Option type="QString" name="name" value=""/>
       <Option name="properties"/>
       <Option type="QString" name="type" value="collection"/>
      </Option>
     </data_defined_properties>
    </layer>
   </symbol>
  </selectionSymbol>
 </selection>
 <blendMode>0</blendMode>
 <featureBlendMode>0</featureBlendMode>
 <layerOpacity>1</layerOpacity>
 <geometryOptions geometryPrecision="0" removeDuplicateNodes="0">
  <activeChecks/>
  <checkConfiguration type="Map">
   <Option type="Map" name="QgsGeometryGapCheck">
    <Option type="double" name="allowedGapsBuffer" value="0"/>
    <Option type="bool" name="allowedGapsEnabled" value="false"/>
    <Option type="invalid" name="allowedGapsLayer"/>
   </Option>
  </checkConfiguration>
 </geometryOptions>
 <legend type="default-vector" showLabelLegend="0"/>
 <conditionalstyles>
  <rowstyles/>
  <fieldstyles/>
 </conditionalstyles>
 <labelOnTop>
  <field name="t50_fid" labelOnTop="0"/>
  <field name="type" labelOnTop="0"/>
 </labelOnTop>
 <previewExpression>"type"</previewExpression>
 <mapTip enabled="1"></mapTip>
</qgis>
