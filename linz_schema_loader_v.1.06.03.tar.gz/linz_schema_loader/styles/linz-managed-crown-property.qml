<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis minScale="100000" autoRefreshMode="Disabled" maxScale="0" labelsEnabled="1" simplifyDrawingHints="1" hasScaleBasedVisibilityFlag="1" version="3.44.8-Solothurn" autoRefreshTime="0" simplifyLocal="1" styleCategories="AllStyleCategories" simplifyDrawingTol="1" simplifyMaxScale="1" readOnly="0" symbologyReferenceScale="-1" simplifyAlgorithm="0">
 <flags>
  <Identifiable>1</Identifiable>
  <Removable>1</Removable>
  <Searchable>1</Searchable>
  <Private>0</Private>
 </flags>
 <elevation binding="Centroid" zoffset="0" zscale="1" clamping="Terrain" symbology="Line" extrusionEnabled="0" type="IndividualFeatures" customToleranceEnabled="0" extrusion="0" respectLayerSymbol="1" showMarkerSymbolInSurfacePlots="0">
  <data-defined-properties>
   <Option type="Map">
    <Option type="QString" name="name" value=""/>
    <Option name="properties"/>
    <Option type="QString" name="type" value="collection"/>
   </Option>
  </data-defined-properties>
  <profileLineSymbol>
   <symbol is_animated="0" frame_rate="10" type="line" alpha="1" clip_to_extent="1" force_rhr="0" name="">
    <data_defined_properties>
     <Option type="Map">
      <Option type="QString" name="name" value=""/>
      <Option name="properties"/>
      <Option type="QString" name="type" value="collection"/>
     </Option>
    </data_defined_properties>
    <layer enabled="1" pass="0" id="{b95ada7c-861e-45d4-9d90-135f62e2ceef}" locked="0" class="SimpleLine">
     <Option type="Map">
      <Option type="QString" name="align_dash_pattern" value="0"/>
      <Option type="QString" name="capstyle" value="square"/>
      <Option type="QString" name="customdash" value="5;2"/>
      <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
      <Option type="QString" name="customdash_unit" value="MM"/>
      <Option type="QString" name="dash_pattern_offset" value="0"/>
      <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
      <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
      <Option type="QString" name="draw_inside_polygon" value="0"/>
      <Option type="QString" name="joinstyle" value="bevel"/>
      <Option type="QString" name="line_color" value="190,178,151,255,rgb:0.745098,0.6980392,0.5921569,1"/>
      <Option type="QString" name="line_style" value="solid"/>
      <Option type="QString" name="line_width" value="0.6"/>
      <Option type="QString" name="line_width_unit" value="MM"/>
      <Option type="QString" name="offset" value="0"/>
      <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
      <Option type="QString" name="offset_unit" value="MM"/>
      <Option type="QString" name="ring_filter" value="0"/>
      <Option type="QString" name="trim_distance_end" value="0"/>
      <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
      <Option type="QString" name="trim_distance_end_unit" value="MM"/>
      <Option type="QString" name="trim_distance_start" value="0"/>
      <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
      <Option type="QString" name="trim_distance_start_unit" value="MM"/>
      <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
      <Option type="QString" name="use_custom_dash" value="0"/>
      <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
     </Option>
     <data_defined_properties>
      <Option type="Map">
       <Option type="QString" name="name" value=""/>
       <Option name="properties"/>
       <Option type="QString" name="type" value="collection"/>
      </Option>
     </data_defined_properties>
    </layer>
   </symbol>
  </profileLineSymbol>
  <profileFillSymbol>
   <symbol is_animated="0" frame_rate="10" type="fill" alpha="1" clip_to_extent="1" force_rhr="0" name="">
    <data_defined_properties>
     <Option type="Map">
      <Option type="QString" name="name" value=""/>
      <Option name="properties"/>
      <Option type="QString" name="type" value="collection"/>
     </Option>
    </data_defined_properties>
    <layer enabled="1" pass="0" id="{3594225f-914c-416c-88c3-0275fa005ec2}" locked="0" class="SimpleFill">
     <Option type="Map">
      <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
      <Option type="QString" name="color" value="190,178,151,255,rgb:0.745098,0.6980392,0.5921569,1"/>
      <Option type="QString" name="joinstyle" value="bevel"/>
      <Option type="QString" name="offset" value="0,0"/>
      <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
      <Option type="QString" name="offset_unit" value="MM"/>
      <Option type="QString" name="outline_color" value="136,127,108,255,rgb:0.5322042,0.4985885,0.4229648,1"/>
      <Option type="QString" name="outline_style" value="solid"/>
      <Option type="QString" name="outline_width" value="0.2"/>
      <Option type="QString" name="outline_width_unit" value="MM"/>
      <Option type="QString" name="style" value="solid"/>
     </Option>
     <data_defined_properties>
      <Option type="Map">
       <Option type="QString" name="name" value=""/>
       <Option name="properties"/>
       <Option type="QString" name="type" value="collection"/>
      </Option>
     </data_defined_properties>
    </layer>
   </symbol>
  </profileFillSymbol>
  <profileMarkerSymbol>
   <symbol is_animated="0" frame_rate="10" type="marker" alpha="1" clip_to_extent="1" force_rhr="0" name="">
    <data_defined_properties>
     <Option type="Map">
      <Option type="QString" name="name" value=""/>
      <Option name="properties"/>
      <Option type="QString" name="type" value="collection"/>
     </Option>
    </data_defined_properties>
    <layer enabled="1" pass="0" id="{07dd0c9a-107f-45b6-bb39-f914205a5f42}" locked="0" class="SimpleMarker">
     <Option type="Map">
      <Option type="QString" name="angle" value="0"/>
      <Option type="QString" name="cap_style" value="square"/>
      <Option type="QString" name="color" value="190,178,151,255,rgb:0.745098,0.6980392,0.5921569,1"/>
      <Option type="QString" name="horizontal_anchor_point" value="1"/>
      <Option type="QString" name="joinstyle" value="bevel"/>
      <Option type="QString" name="name" value="diamond"/>
      <Option type="QString" name="offset" value="0,0"/>
      <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
      <Option type="QString" name="offset_unit" value="MM"/>
      <Option type="QString" name="outline_color" value="136,127,108,255,rgb:0.5322042,0.4985885,0.4229648,1"/>
      <Option type="QString" name="outline_style" value="solid"/>
      <Option type="QString" name="outline_width" value="0.2"/>
      <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
      <Option type="QString" name="outline_width_unit" value="MM"/>
      <Option type="QString" name="scale_method" value="diameter"/>
      <Option type="QString" name="size" value="3"/>
      <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
      <Option type="QString" name="size_unit" value="MM"/>
      <Option type="QString" name="vertical_anchor_point" value="1"/>
     </Option>
     <data_defined_properties>
      <Option type="Map">
       <Option type="QString" name="name" value=""/>
       <Option name="properties"/>
       <Option type="QString" name="type" value="collection"/>
      </Option>
     </data_defined_properties>
    </layer>
   </symbol>
  </profileMarkerSymbol>
 </elevation>
 <renderer-v2 type="singleSymbol" enableorderby="0" referencescale="-1" forceraster="0" symbollevels="0">
  <symbols>
   <symbol is_animated="0" frame_rate="10" type="fill" alpha="0.5" clip_to_extent="1" force_rhr="0" name="0">
    <data_defined_properties>
     <Option type="Map">
      <Option type="QString" name="name" value=""/>
      <Option name="properties"/>
      <Option type="QString" name="type" value="collection"/>
     </Option>
    </data_defined_properties>
    <layer enabled="1" pass="0" id="{297aa5ba-6aca-42a1-97e7-9a8f37c5811b}" locked="0" class="SimpleFill">
     <Option type="Map">
      <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
      <Option type="QString" name="color" value="251,154,153,255,rgb:0.9843137,0.6039216,0.6,1"/>
      <Option type="QString" name="joinstyle" value="bevel"/>
      <Option type="QString" name="offset" value="0,0"/>
      <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
      <Option type="QString" name="offset_unit" value="MM"/>
      <Option type="QString" name="outline_color" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1"/>
      <Option type="QString" name="outline_style" value="solid"/>
      <Option type="QString" name="outline_width" value="0.26"/>
      <Option type="QString" name="outline_width_unit" value="MM"/>
      <Option type="QString" name="style" value="solid"/>
     </Option>
     <data_defined_properties>
      <Option type="Map">
       <Option type="QString" name="name" value=""/>
       <Option name="properties"/>
       <Option type="QString" name="type" value="collection"/>
      </Option>
     </data_defined_properties>
    </layer>
   </symbol>
  </symbols>
  <rotation/>
  <sizescale/>
  <data-defined-properties>
   <Option type="Map">
    <Option type="QString" name="name" value=""/>
    <Option name="properties"/>
    <Option type="QString" name="type" value="collection"/>
   </Option>
  </data-defined-properties>
 </renderer-v2>
 <selection mode="Default">
  <selectionColor invalid="1"/>
  <selectionSymbol>
   <symbol is_animated="0" frame_rate="10" type="fill" alpha="1" clip_to_extent="1" force_rhr="0" name="">
    <data_defined_properties>
     <Option type="Map">
      <Option type="QString" name="name" value=""/>
      <Option name="properties"/>
      <Option type="QString" name="type" value="collection"/>
     </Option>
    </data_defined_properties>
    <layer enabled="1" pass="0" id="{728ac92a-7a7c-44a2-ad91-ac888de87208}" locked="0" class="SimpleFill">
     <Option type="Map">
      <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
      <Option type="QString" name="color" value="0,0,255,255,rgb:0,0,1,1"/>
      <Option type="QString" name="joinstyle" value="bevel"/>
      <Option type="QString" name="offset" value="0,0"/>
      <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
      <Option type="QString" name="offset_unit" value="MM"/>
      <Option type="QString" name="outline_color" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1"/>
      <Option type="QString" name="outline_style" value="solid"/>
      <Option type="QString" name="outline_width" value="0.26"/>
      <Option type="QString" name="outline_width_unit" value="MM"/>
      <Option type="QString" name="style" value="solid"/>
     </Option>
     <data_defined_properties>
      <Option type="Map">
       <Option type="QString" name="name" value=""/>
       <Option name="properties"/>
       <Option type="QString" name="type" value="collection"/>
      </Option>
     </data_defined_properties>
    </layer>
   </symbol>
  </selectionSymbol>
 </selection>
 <labeling type="simple">
  <settings calloutType="simple">
   <text-style forcedBold="0" multilineHeight="1" fontSize="8" fontItalic="0" fontStrikeout="0" fontWeight="50" tabStopDistanceUnit="Point" textOpacity="1" fontSizeMapUnitScale="3x:0,0,0,0,0,0" tabStopDistanceMapUnitScale="3x:0,0,0,0,0,0" fontLetterSpacing="0" fontSizeUnit="Point" previewBkgrdColor="255,255,255,255,rgb:1,1,1,1" tabStopDistance="80" capitalization="0" fontUnderline="0" fontFamily="Open Sans" isExpression="0" namedStyle="Regular" legendString="Aa" textColor="50,50,50,255,rgb:0.1960784,0.1960784,0.1960784,1" textOrientation="horizontal" blendMode="0" multilineHeightUnit="Percentage" fontWordSpacing="0" useSubstitutions="0" fieldName="land_use" forcedItalic="0" fontKerning="1" allowHtml="0">
    <families/>
    <text-buffer bufferSizeUnits="MM" bufferJoinStyle="128" bufferBlendMode="0" bufferNoFill="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferDraw="0" bufferOpacity="1" bufferSize="1" bufferColor="250,250,250,255,rgb:0.9803922,0.9803922,0.9803922,1"/>
    <text-mask maskType="0" maskJoinStyle="128" maskedSymbolLayers="" maskEnabled="0" maskSize="1.5" maskSize2="1.5" maskOpacity="1" maskSizeUnits="MM" maskSizeMapUnitScale="3x:0,0,0,0,0,0"/>
    <background shapeBlendMode="0" shapeRotationType="0" shapeFillColor="255,255,255,255,rgb:1,1,1,1" shapeBorderColor="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1" shapeRadiiX="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="Point" shapeRotation="0" shapeDraw="0" shapeSVGFile="" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="Point" shapeType="0" shapeOffsetY="0" shapeSizeType="0" shapeBorderWidth="0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetUnit="Point" shapeSizeY="0" shapeOpacity="1" shapeRadiiY="0" shapeBorderWidthUnit="Point" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeJoinStyle="64" shapeOffsetX="0">
     <symbol is_animated="0" frame_rate="10" type="marker" alpha="1" clip_to_extent="1" force_rhr="0" name="markerSymbol">
      <data_defined_properties>
       <Option type="Map">
        <Option type="QString" name="name" value=""/>
        <Option name="properties"/>
        <Option type="QString" name="type" value="collection"/>
       </Option>
      </data_defined_properties>
      <layer enabled="1" pass="0" id="" locked="0" class="SimpleMarker">
       <Option type="Map">
        <Option type="QString" name="angle" value="0"/>
        <Option type="QString" name="cap_style" value="square"/>
        <Option type="QString" name="color" value="196,60,57,255,rgb:0.7686275,0.2352941,0.2235294,1"/>
        <Option type="QString" name="horizontal_anchor_point" value="1"/>
        <Option type="QString" name="joinstyle" value="bevel"/>
        <Option type="QString" name="name" value="circle"/>
        <Option type="QString" name="offset" value="0,0"/>
        <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
        <Option type="QString" name="offset_unit" value="MM"/>
        <Option type="QString" name="outline_color" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1"/>
        <Option type="QString" name="outline_style" value="solid"/>
        <Option type="QString" name="outline_width" value="0"/>
        <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
        <Option type="QString" name="outline_width_unit" value="MM"/>
        <Option type="QString" name="scale_method" value="diameter"/>
        <Option type="QString" name="size" value="2"/>
        <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
        <Option type="QString" name="size_unit" value="MM"/>
        <Option type="QString" name="vertical_anchor_point" value="1"/>
       </Option>
       <data_defined_properties>
        <Option type="Map">
         <Option type="QString" name="name" value=""/>
         <Option name="properties"/>
         <Option type="QString" name="type" value="collection"/>
        </Option>
       </data_defined_properties>
      </layer>
     </symbol>
     <symbol is_animated="0" frame_rate="10" type="fill" alpha="1" clip_to_extent="1" force_rhr="0" name="fillSymbol">
      <data_defined_properties>
       <Option type="Map">
        <Option type="QString" name="name" value=""/>
        <Option name="properties"/>
        <Option type="QString" name="type" value="collection"/>
       </Option>
      </data_defined_properties>
      <layer enabled="1" pass="0" id="" locked="0" class="SimpleFill">
       <Option type="Map">
        <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
        <Option type="QString" name="color" value="255,255,255,255,rgb:1,1,1,1"/>
        <Option type="QString" name="joinstyle" value="bevel"/>
        <Option type="QString" name="offset" value="0,0"/>
        <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
        <Option type="QString" name="offset_unit" value="MM"/>
        <Option type="QString" name="outline_color" value="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1"/>
        <Option type="QString" name="outline_style" value="no"/>
        <Option type="QString" name="outline_width" value="0"/>
        <Option type="QString" name="outline_width_unit" value="Point"/>
        <Option type="QString" name="style" value="solid"/>
       </Option>
       <data_defined_properties>
        <Option type="Map">
         <Option type="QString" name="name" value=""/>
         <Option name="properties"/>
         <Option type="QString" name="type" value="collection"/>
        </Option>
       </data_defined_properties>
      </layer>
     </symbol>
    </background>
    <shadow shadowOffsetUnit="MM" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetDist="1" shadowScale="100" shadowRadiusUnit="MM" shadowDraw="0" shadowOffsetGlobal="1" shadowOpacity="0.69999999999999996" shadowBlendMode="6" shadowRadiusAlphaOnly="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowColor="0,0,0,255,rgb:0,0,0,1" shadowOffsetAngle="135" shadowRadius="1.5" shadowUnder="0"/>
    <dd_properties>
     <Option type="Map">
      <Option type="QString" name="name" value=""/>
      <Option name="properties"/>
      <Option type="QString" name="type" value="collection"/>
     </Option>
    </dd_properties>
    <substitutions/>
   </text-style>
   <text-format rightDirectionSymbol=">" placeDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" multilineAlign="3" addDirectionSymbol="0" reverseDirectionSymbol="0" autoWrapLength="20" wrapChar="" formatNumbers="0" plussign="0" leftDirectionSymbol="&lt;" decimals="3"/>
   <placement maxCurvedCharAngleIn="25" placementFlags="10" geometryGeneratorEnabled="0" repeatDistanceUnits="MM" maximumDistanceMapUnitScale="3x:0,0,0,0,0,0" yOffset="0" lineAnchorClipping="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistance="0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" lineAnchorPercent="0.5" distUnits="MM" lineAnchorType="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" maximumDistanceUnit="MM" placement="0" priority="5" quadOffset="4" centroidInside="0" preserveRotation="1" repeatDistance="0" xOffset="0" overlapHandling="PreventOverlap" prioritization="PreferCloser" overrunDistanceUnit="MM" geometryGeneratorType="PointGeometry" lineAnchorTextPoint="FollowPlacement" offsetType="0" centroidWhole="0" offsetUnits="MM" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" geometryGenerator="" distMapUnitScale="3x:0,0,0,0,0,0" rotationAngle="0" polygonPlacementFlags="2" maxCurvedCharAngleOut="-25" rotationUnit="AngleDegrees" dist="0" fitInPolygonOnly="0" maximumDistance="0" allowDegraded="0" layerType="PolygonGeometry"/>
   <rendering limitNumLabels="0" scaleVisibility="0" upsidedownLabels="0" unplacedVisibility="0" fontLimitPixelSize="0" drawLabels="1" minFeatureSize="0" obstacleType="1" obstacleFactor="1" fontMinPixelSize="3" fontMaxPixelSize="10000" labelPerPart="0" mergeLines="0" scaleMax="0" zIndex="0" scaleMin="0" obstacle="1" maxNumLabels="2000"/>
   <dd_properties>
    <Option type="Map">
     <Option type="QString" name="name" value=""/>
     <Option name="properties"/>
     <Option type="QString" name="type" value="collection"/>
    </Option>
   </dd_properties>
   <callout type="simple">
    <Option type="Map">
     <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
     <Option type="int" name="blendMode" value="0"/>
     <Option type="Map" name="ddProperties">
      <Option type="QString" name="name" value=""/>
      <Option name="properties"/>
      <Option type="QString" name="type" value="collection"/>
     </Option>
     <Option type="bool" name="drawToAllParts" value="false"/>
     <Option type="QString" name="enabled" value="0"/>
     <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
     <Option type="QString" name="lineSymbol" value="&lt;symbol is_animated=&quot;0&quot; frame_rate=&quot;10&quot; type=&quot;line&quot; alpha=&quot;1&quot; clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; name=&quot;symbol&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; pass=&quot;0&quot; id=&quot;{6e65a95e-a365-434a-a708-e492b955f32b}&quot; locked=&quot;0&quot; class=&quot;SimpleLine&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255,rgb:0.2352941,0.2352941,0.2352941,1&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
     <Option type="double" name="minLength" value="0"/>
     <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
     <Option type="QString" name="minLengthUnit" value="MM"/>
     <Option type="double" name="offsetFromAnchor" value="0"/>
     <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
     <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
     <Option type="double" name="offsetFromLabel" value="0"/>
     <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
     <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
    </Option>
   </callout>
  </settings>
 </labeling>
 <blendMode>0</blendMode>
 <featureBlendMode>0</featureBlendMode>
 <layerOpacity>1</layerOpacity>
 <SingleCategoryDiagramRenderer attributeLegend="1" diagramType="Histogram">
  <DiagramCategory backgroundColor="#ffffff" opacity="1" spacing="5" spacingUnit="MM" stackedDiagramSpacingUnitScale="3x:0,0,0,0,0,0" scaleBasedVisibility="1" labelPlacementMethod="XHeight" lineSizeScale="3x:0,0,0,0,0,0" direction="0" maxScaleDenominator="100000" sizeType="MM" enabled="0" minimumSize="0" penColor="#000000" diagramOrientation="Up" stackedDiagramMode="Horizontal" stackedDiagramSpacing="0" height="15" scaleDependency="Area" stackedDiagramSpacingUnit="MM" sizeScale="3x:0,0,0,0,0,0" rotationOffset="270" spacingUnitScale="3x:0,0,0,0,0,0" barWidth="5" showAxis="1" penAlpha="255" backgroundAlpha="255" lineSizeType="MM" minScaleDenominator="0" width="15" penWidth="0">
   <fontProperties strikethrough="0" bold="0" style="Regular" italic="0" underline="0" description="Noto Sans,10,-1,5,50,0,0,0,0,0,Regular"/>
   <attribute color="#000000" field="" colorOpacity="1" label=""/>
   <axisSymbol>
    <symbol is_animated="0" frame_rate="10" type="line" alpha="1" clip_to_extent="1" force_rhr="0" name="">
     <data_defined_properties>
      <Option type="Map">
       <Option type="QString" name="name" value=""/>
       <Option name="properties"/>
       <Option type="QString" name="type" value="collection"/>
      </Option>
     </data_defined_properties>
     <layer enabled="1" pass="0" id="{4d332c0a-cf7c-41be-96ad-67b204b6ce40}" locked="0" class="SimpleLine">
      <Option type="Map">
       <Option type="QString" name="align_dash_pattern" value="0"/>
       <Option type="QString" name="capstyle" value="square"/>
       <Option type="QString" name="customdash" value="5;2"/>
       <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
       <Option type="QString" name="customdash_unit" value="MM"/>
       <Option type="QString" name="dash_pattern_offset" value="0"/>
       <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
       <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
       <Option type="QString" name="draw_inside_polygon" value="0"/>
       <Option type="QString" name="joinstyle" value="bevel"/>
       <Option type="QString" name="line_color" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1"/>
       <Option type="QString" name="line_style" value="solid"/>
       <Option type="QString" name="line_width" value="0.26"/>
       <Option type="QString" name="line_width_unit" value="MM"/>
       <Option type="QString" name="offset" value="0"/>
       <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
       <Option type="QString" name="offset_unit" value="MM"/>
       <Option type="QString" name="ring_filter" value="0"/>
       <Option type="QString" name="trim_distance_end" value="0"/>
       <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
       <Option type="QString" name="trim_distance_end_unit" value="MM"/>
       <Option type="QString" name="trim_distance_start" value="0"/>
       <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
       <Option type="QString" name="trim_distance_start_unit" value="MM"/>
       <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
       <Option type="QString" name="use_custom_dash" value="0"/>
       <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
      </Option>
      <data_defined_properties>
       <Option type="Map">
        <Option type="QString" name="name" value=""/>
        <Option name="properties"/>
        <Option type="QString" name="type" value="collection"/>
       </Option>
      </data_defined_properties>
     </layer>
    </symbol>
   </axisSymbol>
  </DiagramCategory>
 </SingleCategoryDiagramRenderer>
 <DiagramLayerSettings priority="0" showAll="1" linePlacementFlags="18" zIndex="0" obstacle="0" placement="1" dist="0">
  <properties>
   <Option type="Map">
    <Option type="QString" name="name" value=""/>
    <Option name="properties"/>
    <Option type="QString" name="type" value="collection"/>
   </Option>
  </properties>
 </DiagramLayerSettings>
 <geometryOptions geometryPrecision="0" removeDuplicateNodes="0">
  <activeChecks/>
  <checkConfiguration type="Map">
   <Option type="Map" name="QgsGeometryGapCheck">
    <Option type="double" name="allowedGapsBuffer" value="0"/>
    <Option type="bool" name="allowedGapsEnabled" value="false"/>
    <Option type="invalid" name="allowedGapsLayer"/>
   </Option>
  </checkConfiguration>
 </geometryOptions>
 <legend type="default-vector" showLabelLegend="0"/>
 <conditionalstyles>
  <rowstyles/>
  <fieldstyles/>
 </conditionalstyles>
 <labelOnTop>
  <field name="administered_under" labelOnTop="0"/>
  <field name="disposal_status" labelOnTop="0"/>
  <field name="land_use" labelOnTop="0"/>
  <field name="napalis_id" labelOnTop="0"/>
  <field name="purpose" labelOnTop="0"/>
 </labelOnTop>
 <previewExpression>"administered_under"</previewExpression>
 <mapTip enabled="1"></mapTip>
</qgis>
