<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis minScale="1000000" autoRefreshMode="Disabled" maxScale="300000" labelsEnabled="0" simplifyDrawingHints="1" hasScaleBasedVisibilityFlag="1" version="3.44.8-Solothurn" autoRefreshTime="0" simplifyLocal="1" styleCategories="AllStyleCategories" simplifyDrawingTol="1" simplifyMaxScale="1" readOnly="0" symbologyReferenceScale="-1" simplifyAlgorithm="0">
 <flags>
  <Identifiable>1</Identifiable>
  <Removable>1</Removable>
  <Searchable>1</Searchable>
  <Private>0</Private>
 </flags>
 <elevation binding="Centroid" zoffset="0" zscale="1" clamping="Terrain" symbology="Line" extrusionEnabled="0" type="IndividualFeatures" customToleranceEnabled="0" extrusion="0" respectLayerSymbol="1" showMarkerSymbolInSurfacePlots="0">
  <data-defined-properties>
   <Option type="Map">
    <Option type="QString" name="name" value=""/>
    <Option name="properties"/>
    <Option type="QString" name="type" value="collection"/>
   </Option>
  </data-defined-properties>
  <profileLineSymbol>
   <symbol is_animated="0" frame_rate="10" type="line" alpha="1" clip_to_extent="1" force_rhr="0" name="">
    <data_defined_properties>
     <Option type="Map">
      <Option type="QString" name="name" value=""/>
      <Option name="properties"/>
      <Option type="QString" name="type" value="collection"/>
     </Option>
    </data_defined_properties>
    <layer enabled="1" pass="0" id="{9b67c885-af28-46cc-88ad-54c5e93e03a3}" locked="0" class="SimpleLine">
     <Option type="Map">
      <Option type="QString" name="align_dash_pattern" value="0"/>
      <Option type="QString" name="capstyle" value="square"/>
      <Option type="QString" name="customdash" value="5;2"/>
      <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
      <Option type="QString" name="customdash_unit" value="MM"/>
      <Option type="QString" name="dash_pattern_offset" value="0"/>
      <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
      <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
      <Option type="QString" name="draw_inside_polygon" value="0"/>
      <Option type="QString" name="joinstyle" value="bevel"/>
      <Option type="QString" name="line_color" value="190,207,80,255,rgb:0.745098,0.8117647,0.3137255,1"/>
      <Option type="QString" name="line_style" value="solid"/>
      <Option type="QString" name="line_width" value="0.6"/>
      <Option type="QString" name="line_width_unit" value="MM"/>
      <Option type="QString" name="offset" value="0"/>
      <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
      <Option type="QString" name="offset_unit" value="MM"/>
      <Option type="QString" name="ring_filter" value="0"/>
      <Option type="QString" name="trim_distance_end" value="0"/>
      <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
      <Option type="QString" name="trim_distance_end_unit" value="MM"/>
      <Option type="QString" name="trim_distance_start" value="0"/>
      <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
      <Option type="QString" name="trim_distance_start_unit" value="MM"/>
      <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
      <Option type="QString" name="use_custom_dash" value="0"/>
      <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
     </Option>
     <data_defined_properties>
      <Option type="Map">
       <Option type="QString" name="name" value=""/>
       <Option name="properties"/>
       <Option type="QString" name="type" value="collection"/>
      </Option>
     </data_defined_properties>
    </layer>
   </symbol>
  </profileLineSymbol>
  <profileFillSymbol>
   <symbol is_animated="0" frame_rate="10" type="fill" alpha="1" clip_to_extent="1" force_rhr="0" name="">
    <data_defined_properties>
     <Option type="Map">
      <Option type="QString" name="name" value=""/>
      <Option name="properties"/>
      <Option type="QString" name="type" value="collection"/>
     </Option>
    </data_defined_properties>
    <layer enabled="1" pass="0" id="{c3947b77-536d-4808-a7f1-d9d0a35d422e}" locked="0" class="SimpleFill">
     <Option type="Map">
      <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
      <Option type="QString" name="color" value="190,207,80,255,rgb:0.745098,0.8117647,0.3137255,1"/>
      <Option type="QString" name="joinstyle" value="bevel"/>
      <Option type="QString" name="offset" value="0,0"/>
      <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
      <Option type="QString" name="offset_unit" value="MM"/>
      <Option type="QString" name="outline_color" value="136,148,57,255,rgb:0.5322194,0.5798276,0.224094,1"/>
      <Option type="QString" name="outline_style" value="solid"/>
      <Option type="QString" name="outline_width" value="0.2"/>
      <Option type="QString" name="outline_width_unit" value="MM"/>
      <Option type="QString" name="style" value="solid"/>
     </Option>
     <data_defined_properties>
      <Option type="Map">
       <Option type="QString" name="name" value=""/>
       <Option name="properties"/>
       <Option type="QString" name="type" value="collection"/>
      </Option>
     </data_defined_properties>
    </layer>
   </symbol>
  </profileFillSymbol>
  <profileMarkerSymbol>
   <symbol is_animated="0" frame_rate="10" type="marker" alpha="1" clip_to_extent="1" force_rhr="0" name="">
    <data_defined_properties>
     <Option type="Map">
      <Option type="QString" name="name" value=""/>
      <Option name="properties"/>
      <Option type="QString" name="type" value="collection"/>
     </Option>
    </data_defined_properties>
    <layer enabled="1" pass="0" id="{bfbcf824-0cb0-4e74-8948-7adbae2d1846}" locked="0" class="SimpleMarker">
     <Option type="Map">
      <Option type="QString" name="angle" value="0"/>
      <Option type="QString" name="cap_style" value="square"/>
      <Option type="QString" name="color" value="190,207,80,255,rgb:0.745098,0.8117647,0.3137255,1"/>
      <Option type="QString" name="horizontal_anchor_point" value="1"/>
      <Option type="QString" name="joinstyle" value="bevel"/>
      <Option type="QString" name="name" value="diamond"/>
      <Option type="QString" name="offset" value="0,0"/>
      <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
      <Option type="QString" name="offset_unit" value="MM"/>
      <Option type="QString" name="outline_color" value="136,148,57,255,rgb:0.5322194,0.5798276,0.224094,1"/>
      <Option type="QString" name="outline_style" value="solid"/>
      <Option type="QString" name="outline_width" value="0.2"/>
      <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
      <Option type="QString" name="outline_width_unit" value="MM"/>
      <Option type="QString" name="scale_method" value="diameter"/>
      <Option type="QString" name="size" value="3"/>
      <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
      <Option type="QString" name="size_unit" value="MM"/>
      <Option type="QString" name="vertical_anchor_point" value="1"/>
     </Option>
     <data_defined_properties>
      <Option type="Map">
       <Option type="QString" name="name" value=""/>
       <Option name="properties"/>
       <Option type="QString" name="type" value="collection"/>
      </Option>
     </data_defined_properties>
    </layer>
   </symbol>
  </profileMarkerSymbol>
 </elevation>
 <renderer-v2 type="singleSymbol" enableorderby="0" referencescale="-1" forceraster="0" symbollevels="0">
  <symbols>
   <symbol is_animated="0" frame_rate="10" type="fill" alpha="1" clip_to_extent="1" force_rhr="0" name="0">
    <data_defined_properties>
     <Option type="Map">
      <Option type="QString" name="name" value=""/>
      <Option name="properties"/>
      <Option type="QString" name="type" value="collection"/>
     </Option>
    </data_defined_properties>
    <layer enabled="1" pass="0" id="{790eddf6-36a1-4fa1-bba6-786fbd4fb4db}" locked="0" class="RandomMarkerFill">
     <Option type="Map">
      <Option type="QString" name="clip_points" value="1"/>
      <Option type="QString" name="count_method" value="1"/>
      <Option type="QString" name="density_area" value="100"/>
      <Option type="QString" name="density_area_unit" value="MM"/>
      <Option type="QString" name="density_area_unit_scale" value="3x:0,0,0,0,0,0"/>
      <Option type="QString" name="point_count" value="15"/>
      <Option type="QString" name="seed" value="640686656"/>
     </Option>
     <data_defined_properties>
      <Option type="Map">
       <Option type="QString" name="name" value=""/>
       <Option name="properties"/>
       <Option type="QString" name="type" value="collection"/>
      </Option>
     </data_defined_properties>
     <symbol is_animated="0" frame_rate="10" type="marker" alpha="1" clip_to_extent="1" force_rhr="0" name="@0@0">
      <data_defined_properties>
       <Option type="Map">
        <Option type="QString" name="name" value=""/>
        <Option name="properties"/>
        <Option type="QString" name="type" value="collection"/>
       </Option>
      </data_defined_properties>
      <layer enabled="1" pass="0" id="{f0e411bd-f33c-42b7-8350-c8bc672fbaea}" locked="0" class="SimpleMarker">
       <Option type="Map">
        <Option type="QString" name="angle" value="0"/>
        <Option type="QString" name="cap_style" value="square"/>
        <Option type="QString" name="color" value="0,0,255,255,rgb:0,0,1,1"/>
        <Option type="QString" name="horizontal_anchor_point" value="1"/>
        <Option type="QString" name="joinstyle" value="bevel"/>
        <Option type="QString" name="name" value="circle"/>
        <Option type="QString" name="offset" value="0,0"/>
        <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
        <Option type="QString" name="offset_unit" value="MM"/>
        <Option type="QString" name="outline_color" value="0,0,255,255,rgb:0,0,1,1"/>
        <Option type="QString" name="outline_style" value="solid"/>
        <Option type="QString" name="outline_width" value="0"/>
        <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
        <Option type="QString" name="outline_width_unit" value="MM"/>
        <Option type="QString" name="scale_method" value="diameter"/>
        <Option type="QString" name="size" value="0.15"/>
        <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
        <Option type="QString" name="size_unit" value="MM"/>
        <Option type="QString" name="vertical_anchor_point" value="1"/>
       </Option>
       <data_defined_properties>
        <Option type="Map">
         <Option type="QString" name="name" value=""/>
         <Option name="properties"/>
         <Option type="QString" name="type" value="collection"/>
        </Option>
       </data_defined_properties>
      </layer>
     </symbol>
    </layer>
    <layer enabled="1" pass="0" id="{87a020a2-c89a-402b-85a0-b1717a288912}" locked="0" class="RandomMarkerFill">
     <Option type="Map">
      <Option type="QString" name="clip_points" value="0"/>
      <Option type="QString" name="count_method" value="1"/>
      <Option type="QString" name="density_area" value="100"/>
      <Option type="QString" name="density_area_unit" value="MM"/>
      <Option type="QString" name="density_area_unit_scale" value="3x:0,0,0,0,0,0"/>
      <Option type="QString" name="point_count" value="12"/>
      <Option type="QString" name="seed" value="74307038"/>
     </Option>
     <data_defined_properties>
      <Option type="Map">
       <Option type="QString" name="name" value=""/>
       <Option name="properties"/>
       <Option type="QString" name="type" value="collection"/>
      </Option>
     </data_defined_properties>
     <symbol is_animated="0" frame_rate="10" type="marker" alpha="1" clip_to_extent="1" force_rhr="0" name="@0@1">
      <data_defined_properties>
       <Option type="Map">
        <Option type="QString" name="name" value=""/>
        <Option name="properties"/>
        <Option type="QString" name="type" value="collection"/>
       </Option>
      </data_defined_properties>
      <layer enabled="1" pass="0" id="{83c30f1b-f0da-4495-bebd-e3386e32d0d3}" locked="0" class="SimpleMarker">
       <Option type="Map">
        <Option type="QString" name="angle" value="0"/>
        <Option type="QString" name="cap_style" value="square"/>
        <Option type="QString" name="color" value="0,0,255,255,rgb:0,0,1,1"/>
        <Option type="QString" name="horizontal_anchor_point" value="1"/>
        <Option type="QString" name="joinstyle" value="bevel"/>
        <Option type="QString" name="name" value="circle"/>
        <Option type="QString" name="offset" value="0,0"/>
        <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
        <Option type="QString" name="offset_unit" value="MM"/>
        <Option type="QString" name="outline_color" value="0,0,255,255,rgb:0,0,1,1"/>
        <Option type="QString" name="outline_style" value="solid"/>
        <Option type="QString" name="outline_width" value="0"/>
        <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
        <Option type="QString" name="outline_width_unit" value="MM"/>
        <Option type="QString" name="scale_method" value="diameter"/>
        <Option type="QString" name="size" value="0.2"/>
        <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
        <Option type="QString" name="size_unit" value="MM"/>
        <Option type="QString" name="vertical_anchor_point" value="1"/>
       </Option>
       <data_defined_properties>
        <Option type="Map">
         <Option type="QString" name="name" value=""/>
         <Option name="properties"/>
         <Option type="QString" name="type" value="collection"/>
        </Option>
       </data_defined_properties>
      </layer>
     </symbol>
    </layer>
   </symbol>
  </symbols>
  <rotation/>
  <sizescale/>
  <data-defined-properties>
   <Option type="Map">
    <Option type="QString" name="name" value=""/>
    <Option name="properties"/>
    <Option type="QString" name="type" value="collection"/>
   </Option>
  </data-defined-properties>
 </renderer-v2>
 <selection mode="Default">
  <selectionColor invalid="1"/>
  <selectionSymbol>
   <symbol is_animated="0" frame_rate="10" type="fill" alpha="1" clip_to_extent="1" force_rhr="0" name="">
    <data_defined_properties>
     <Option type="Map">
      <Option type="QString" name="name" value=""/>
      <Option name="properties"/>
      <Option type="QString" name="type" value="collection"/>
     </Option>
    </data_defined_properties>
    <layer enabled="1" pass="0" id="{f5ef4237-a932-4ebc-b7c7-1b9a8fc78aed}" locked="0" class="SimpleFill">
     <Option type="Map">
      <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
      <Option type="QString" name="color" value="0,0,255,255,rgb:0,0,1,1"/>
      <Option type="QString" name="joinstyle" value="bevel"/>
      <Option type="QString" name="offset" value="0,0"/>
      <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
      <Option type="QString" name="offset_unit" value="MM"/>
      <Option type="QString" name="outline_color" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1"/>
      <Option type="QString" name="outline_style" value="solid"/>
      <Option type="QString" name="outline_width" value="0.26"/>
      <Option type="QString" name="outline_width_unit" value="MM"/>
      <Option type="QString" name="style" value="solid"/>
     </Option>
     <data_defined_properties>
      <Option type="Map">
       <Option type="QString" name="name" value=""/>
       <Option name="properties"/>
       <Option type="QString" name="type" value="collection"/>
      </Option>
     </data_defined_properties>
    </layer>
   </symbol>
  </selectionSymbol>
 </selection>
 <blendMode>0</blendMode>
 <featureBlendMode>0</featureBlendMode>
 <layerOpacity>1</layerOpacity>
 <DiagramLayerSettings priority="0" showAll="1" linePlacementFlags="18" zIndex="0" obstacle="0" placement="1" dist="0">
  <properties>
   <Option type="Map">
    <Option type="QString" name="name" value=""/>
    <Option name="properties"/>
    <Option type="QString" name="type" value="collection"/>
   </Option>
  </properties>
 </DiagramLayerSettings>
 <geometryOptions geometryPrecision="0" removeDuplicateNodes="0">
  <activeChecks/>
  <checkConfiguration type="Map">
   <Option type="Map" name="QgsGeometryGapCheck">
    <Option type="double" name="allowedGapsBuffer" value="0"/>
    <Option type="bool" name="allowedGapsEnabled" value="false"/>
    <Option type="invalid" name="allowedGapsLayer"/>
   </Option>
  </checkConfiguration>
 </geometryOptions>
 <legend type="default-vector" showLabelLegend="0"/>
 <conditionalstyles>
  <rowstyles/>
  <fieldstyles/>
 </conditionalstyles>
 <labelOnTop>
  <field name="FID" labelOnTop="0"/>
 </labelOnTop>
 <previewExpression>"FID"</previewExpression>
 <mapTip enabled="1"></mapTip>
</qgis>
