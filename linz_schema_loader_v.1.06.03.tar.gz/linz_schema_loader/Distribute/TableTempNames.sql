/**
 * Author:  Grant
 * Created: Jul 3, 2025
 *
 * Instructions for creating tempory empty copy of schema tables
 * to enable QGIS project and layer property maintenance 
 * without QGIS stalling
 */

# PURGE BINARY LOGS
# from shell...
ls -alh /db/mariadb/bin_log
mariadb -p --user=root linz
>
PURGE BINARY LOGS TO 'mysql-bin.000nnn';
# or
PURGE BINARY LOGS BEFORE '2025-MM-dd';
# or
PURGE BINARY LOGS BEFORE '2025-MM-dd hh:mm:ss';

# from shell...
mariadb -p --user=root linz
>
# drop views before making copies of table definitions
DROP VIEW linz.nz_parcel_owners_vw;
DROP VIEW linz.nz_parcel_titles_vw;
DROP VIEW linz.nz_title_owners_vw;
DROP VIEW linz.properties_buildings_vw;
DROP VIEW linz.properties_details_vw;
DROP VIEW linz.properties_valuation_details_vw;

#############################################

Create new temp directory, eg:
md /db/mariadb/tmp
chown -Rv mysql:mysql /db/mariadb/tmp
chmod -Rv 775 /db/mariadb/tmp

Edit /etc/my.cnf

add line to section [mysqld]
tmpdir = /db/mariadb/tmp

#############################################

SELECT TABLE_SCHEMA, TABLE_NAME, COLUMN_NAME
FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA='linz'
AND TABLE_NAME NOT IN ('geometry_columns', 'spatial_ref_sys', 'table_datasets')
and right(TABLE_NAME,3) != '_vw'
and right(COLUMN_NAME,6) != 'status'
and right(COLUMN_NAME,7) != 'default'
and right(COLUMN_NAME,5) != 'value'
and right(COLUMN_NAME,4) != 'type'
and right(COLUMN_NAME,11) != 'description'
and right(COLUMN_NAME,4) != 'date'
and right(COLUMN_NAME,4) != 'flag'
and right(COLUMN_NAME,4) != 'size'
and right(COLUMN_NAME,4) != 'text'
and right(COLUMN_NAME,4) != 'area'
and right(COLUMN_NAME,5) != 'titles'
and right(COLUMN_NAME,4) != 'view'
and right(COLUMN_NAME,3) != 'use'
and right(COLUMN_NAME,4) != 'body'
and right(COLUMN_NAME,6) != 'prefix'
and right(COLUMN_NAME,6) != 'suffix'
and right(COLUMN_NAME,5) != 'ascii'
and right(COLUMN_NAME,4) != 'walk'
and right(COLUMN_NAME,5) != 'cycle'
and right(COLUMN_NAME,5) != 'count'
and right(COLUMN_NAME,5) != 'label'
and right(COLUMN_NAME,5) != 'class'
and right(COLUMN_NAME,5) != 'alpha'
and right(COLUMN_NAME,5) != 'group'
and right(COLUMN_NAME,4) != 'uses'
and right(COLUMN_NAME,6) != 'titles'
and right(COLUMN_NAME,8) != 'district'
and right(COLUMN_NAME,4) != 'cols'
and right(COLUMN_NAME,6) != 'source'
and right(COLUMN_NAME,7) != 'purpose'
and right(COLUMN_NAME,4) != 'span'
and right(COLUMN_NAME,6) != 'intent'
and right(COLUMN_NAME,7) != 'actions'
and right(COLUMN_NAME,7) != 'surveys'
and right(COLUMN_NAME,9) != 'indicator'
and right(COLUMN_NAME,5) != 'share'
and right(COLUMN_NAME,4) != 'term'
and right(COLUMN_NAME,11) != 'appellation'
EXCEPT
SELECT TABLE_SCHEMA, TABLE_NAME, COLUMN_NAME
FROM information_schema.statistics
WHERE TABLE_SCHEMA='linz'
order by TABLE_SCHEMA, TABLE_NAME, COLUMN_NAME
;

ALTER TABLE linz.south_island_pastoral_leases
ADD INDEX (lease_name);

#############################################

# make empty table replica of large tables
RENAME TABLE linz.landonline_encumbrance TO linz.landonline_encumbrance_temp;
CREATE TABLE linz.landonline_encumbrance LIKE linz.landonline_encumbrance_temp;

RENAME TABLE linz.landonline_encumbrancee TO linz.landonline_encumbrancee_temp;
CREATE TABLE linz.landonline_encumbrancee LIKE linz.landonline_encumbrancee_temp;

RENAME TABLE linz.landonline_encumbrance_share TO linz.landonline_encumbrance_share_temp;
CREATE TABLE linz.landonline_encumbrance_share LIKE linz.landonline_encumbrance_share_temp;

RENAME TABLE linz.landonline_title_encumbrance TO linz.landonline_title_encumbrance_temp;
CREATE TABLE linz.landonline_title_encumbrance LIKE linz.landonline_title_encumbrance_temp;

RENAME TABLE linz.landonline_title_parcel_association TO linz.landonline_title_parcel_association_temp;
CREATE TABLE linz.landonline_title_parcel_association LIKE linz.landonline_title_parcel_association_temp;

RENAME TABLE linz.landonline_title_memorial TO linz.landonline_title_memorial_temp;
CREATE TABLE linz.landonline_title_memorial LIKE linz.landonline_title_memorial_temp;

RENAME TABLE linz.landonline_title_memorial_text TO linz.landonline_title_memorial_text_temp;
CREATE TABLE linz.landonline_title_memorial_text LIKE linz.landonline_title_memorial_text_temp;

RENAME TABLE linz.nz_linear_parcels TO linz.nz_linear_parcels_temp;
CREATE TABLE linz.nz_linear_parcels LIKE linz.nz_linear_parcels_temp;

RENAME TABLE linz.nz_non_primary_linear_parcels TO linz.nz_non_primary_linear_parcels_temp;
CREATE TABLE linz.nz_non_primary_linear_parcels LIKE linz.nz_non_primary_linear_parcels_temp;

RENAME TABLE linz.nz_non_primary_parcels TO linz.nz_non_primary_parcels_temp;
CREATE TABLE linz.nz_non_primary_parcels LIKE linz.nz_non_primary_parcels_temp;

RENAME TABLE linz.nz_primary_hydro_parcels TO linz.nz_primary_hydro_parcels_temp;
CREATE TABLE linz.nz_primary_hydro_parcels LIKE linz.nz_primary_hydro_parcels_temp;

RENAME TABLE linz.nz_property_titles_list TO linz.nz_property_titles_list_temp;
CREATE TABLE linz.nz_property_titles_list LIKE linz.nz_property_titles_list_temp;

RENAME TABLE linz.nz_title_parcel_association_list TO linz.nz_title_parcel_association_list_temp;
CREATE TABLE linz.nz_title_parcel_association_list LIKE linz.nz_title_parcel_association_list_temp;

RENAME TABLE linz.protected_areas TO linz.protected_areas_temp;
CREATE TABLE linz.protected_areas LIKE linz.protected_areas_temp;

RENAME TABLE linz.protected_areas_to_parcel_association TO linz.protected_areas_to_parcel_association_temp;
CREATE TABLE linz.protected_areas_to_parcel_association LIKE linz.protected_areas_to_parcel_association_temp;

RENAME TABLE linz.nz_building_outlines_all_sources TO linz.nz_building_outlines_all_sources_temp;
CREATE TABLE linz.nz_building_outlines_all_sources LIKE linz.nz_building_outlines_all_sources_temp;

RENAME TABLE linz.nz_title_memorials_list_including_mortgages_leases_easements TO linz.nz_title_memorials_list_including_mortgages_leases_easements_t;
CREATE TABLE linz.nz_title_memorials_list_including_mortgages_leases_easements LIKE linz.nz_title_memorials_list_including_mortgages_leases_easements_t;

RENAME TABLE linz.nz_title_memorials_additional_text_list TO linz.nz_title_memorials_additional_text_list_temp;
CREATE TABLE linz.nz_title_memorials_additional_text_list LIKE linz.nz_title_memorials_additional_text_list_temp;

RENAME TABLE linz.nz_primary_land_parcels TO linz.nz_primary_land_parcels_temp;
CREATE TABLE linz.nz_primary_land_parcels LIKE linz.nz_primary_land_parcels_temp;

RENAME TABLE linz.nz_property_titles TO linz.nz_property_titles_temp;
CREATE TABLE linz.nz_property_titles LIKE linz.nz_property_titles_temp;

RENAME TABLE linz.nz_property_titles_including_owners TO linz.nz_property_titles_including_owners_temp;
CREATE TABLE linz.nz_property_titles_including_owners LIKE linz.nz_property_titles_including_owners_temp;

RENAME TABLE linz.nz_property_title_owners TO linz.nz_property_title_owners_temp;
CREATE TABLE linz.nz_property_title_owners LIKE linz.nz_property_title_owners_temp;

RENAME TABLE linz.nz_addresses TO linz.nz_addresses_temp;
CREATE TABLE linz.nz_addresses LIKE linz.nz_addresses_temp;

RENAME TABLE linz.nz_primary_road_parcels TO linz.nz_primary_road_parcels_temp;
CREATE TABLE linz.nz_primary_road_parcels LIKE linz.nz_primary_road_parcels_temp;

RENAME TABLE linz.nz_roads_addressing TO linz.nz_roads_addressing_temp;
CREATE TABLE linz.nz_roads_addressing LIKE linz.nz_roads_addressing_temp;

RENAME TABLE linz.nz_property_titles_owners_list TO linz.nz_property_titles_owners_list_temp;
CREATE TABLE linz.nz_property_titles_owners_list LIKE linz.nz_property_titles_owners_list_temp;

RENAME TABLE linz.nz_properties_national_district_valuation_roll TO linz.nz_properties_national_district_valuation_roll_temp;
CREATE TABLE linz.nz_properties_national_district_valuation_roll LIKE linz.nz_properties_national_district_valuation_roll_temp;

RENAME TABLE linz.nz_properties_parent_property TO linz.nz_properties_parent_property_temp;
CREATE TABLE linz.nz_properties_parent_property LIKE linz.nz_properties_parent_property_temp;

RENAME TABLE linz.nz_properties_perspective TO linz.nz_properties_perspective_temp;
CREATE TABLE linz.nz_properties_perspective LIKE linz.nz_properties_perspective_temp;

RENAME TABLE linz.nz_properties_property_address_reference TO linz.nz_properties_property_address_reference_temp;
CREATE TABLE linz.nz_properties_property_address_reference LIKE linz.nz_properties_property_address_reference_temp;

RENAME TABLE linz.nz_properties_property_building_reference TO linz.nz_properties_property_building_reference_temp;
CREATE TABLE linz.nz_properties_property_building_reference LIKE linz.nz_properties_property_building_reference_temp;

RENAME TABLE linz.nz_properties_property_title_reference TO linz.nz_properties_property_title_reference_temp;
CREATE TABLE linz.nz_properties_property_title_reference LIKE linz.nz_properties_property_title_reference_temp;

RENAME TABLE linz.nz_properties_unit_of_property TO linz.nz_properties_unit_of_property_temp;
CREATE TABLE linz.nz_properties_unit_of_property LIKE linz.nz_properties_unit_of_property_temp;

RENAME TABLE linz.nz_fence_centrelines_topo_150k TO linz.nz_fence_centrelines_topo_150k_temp;
CREATE TABLE linz.nz_fence_centrelines_topo_150k LIKE linz.nz_fence_centrelines_topo_150k_temp;

RENAME TABLE linz.nz_road_centrelines_topo_150k TO linz.nz_road_centrelines_topo_150k_temp;
CREATE TABLE linz.nz_road_centrelines_topo_150k LIKE linz.nz_road_centrelines_topo_150k_temp;

RENAME TABLE linz.nz_track_centrelines_topo_150k TO linz.nz_track_centrelines_topo_150k_temp;
CREATE TABLE linz.nz_track_centrelines_topo_150k LIKE linz.nz_track_centrelines_topo_150k_temp;

#############################################
# Recreate views using LINZschema without loading data
# Make changes to QGIS
#############################################

# restore large  tables
DROP TABLE linz.landonline_encumbrance;
RENAME TABLE linz.landonline_encumbrance_temp TO linz.landonline_encumbrance;

DROP TABLE linz.landonline_encumbrancee;
RENAME TABLE linz.landonline_encumbrancee_temp TO linz.landonline_encumbrancee;

DROP TABLE linz.landonline_encumbrance_share;
RENAME TABLE linz.landonline_encumbrance_share_temp TO linz.landonline_encumbrance_share;

DROP TABLE linz.landonline_title_encumbrance;
RENAME TABLE linz.landonline_title_encumbrance_temp TO linz.landonline_title_encumbrance;

DROP TABLE linz.landonline_title_parcel_association;
RENAME TABLE linz.landonline_title_parcel_association_temp TO linz.landonline_title_parcel_association;

DROP TABLE linz.landonline_title_memorial;
RENAME TABLE linz.landonline_title_memorial_temp TO linz.landonline_title_memorial;

DROP TABLE linz.landonline_title_memorial_text;
RENAME TABLE linz.landonline_title_memorial_text_temp TO linz.landonline_title_memorial_text;

DROP TABLE linz.nz_linear_parcels;
RENAME TABLE linz.nz_linear_parcels_temp TO linz.nz_linear_parcels;

DROP TABLE linz.nz_non_primary_linear_parcels;
RENAME TABLE linz.nz_non_primary_linear_parcels_temp TO linz.nz_non_primary_linear_parcels;

DROP TABLE linz.nz_non_primary_parcels;
RENAME TABLE linz.nz_non_primary_parcels_temp TO linz.nz_non_primary_parcels;

DROP TABLE linz.nz_primary_hydro_parcels;
RENAME TABLE linz.nz_primary_hydro_parcels_temp TO linz.nz_primary_hydro_parcels;

DROP TABLE linz.nz_property_titles_list;
RENAME TABLE linz.nz_property_titles_list_temp TO linz.nz_property_titles_list;

DROP TABLE linz.nz_title_parcel_association_list;
RENAME TABLE linz.nz_title_parcel_association_list_temp TO linz.nz_title_parcel_association_list;

DROP TABLE linz.protected_areas;
RENAME TABLE linz.protected_areas_temp TO linz.protected_areas;

DROP TABLE linz.protected_areas_to_parcel_association;
RENAME TABLE linz.protected_areas_to_parcel_association_temp TO linz.protected_areas_to_parcel_association;

DROP TABLE linz.nz_building_outlines_all_sources;
RENAME TABLE linz.nz_building_outlines_all_sources_temp TO linz.nz_building_outlines_all_sources;

DROP TABLE linz.nz_title_memorials_list_including_mortgages_leases_easements;
RENAME TABLE linz.nz_title_memorials_list_including_mortgages_leases_easements_t TO linz.nz_title_memorials_list_including_mortgages_leases_easements;

DROP TABLE linz.nz_title_memorials_additional_text_list;
RENAME TABLE linz.nz_title_memorials_additional_text_list_temp TO linz.nz_title_memorials_additional_text_list;

DROP TABLE linz.nz_primary_land_parcels;
RENAME TABLE linz.nz_primary_land_parcels_temp TO linz.nz_primary_land_parcels;

DROP TABLE linz.nz_property_titles;
RENAME TABLE linz.nz_property_titles_temp TO linz.nz_property_titles;

DROP TABLE linz.nz_property_titles_including_owners;
RENAME TABLE linz.nz_property_titles_including_owners_temp TO linz.nz_property_titles_including_owners;

DROP TABLE linz.nz_property_title_owners;
RENAME TABLE linz.nz_property_title_owners_temp TO linz.nz_property_title_owners;

DROP TABLE linz.nz_addresses;
RENAME TABLE linz.nz_addresses_temp TO linz.nz_addresses;

DROP TABLE linz.nz_primary_road_parcels;
RENAME TABLE linz.nz_primary_road_parcels_temp TO linz.nz_primary_road_parcels;

DROP TABLE linz.nz_roads_addressing;
RENAME TABLE linz.nz_roads_addressing_temp TO linz.nz_roads_addressing;

DROP TABLE linz.nz_property_titles_owners_list;
RENAME TABLE linz.nz_property_titles_owners_list_temp TO linz.nz_property_titles_owners_list;

DROP TABLE linz.nz_properties_national_district_valuation_roll;
RENAME TABLE linz.nz_properties_national_district_valuation_roll_temp TO linz.nz_properties_national_district_valuation_roll;

DROP TABLE linz.nz_properties_parent_property;
RENAME TABLE linz.nz_properties_parent_property_temp TO linz.nz_properties_parent_property;

DROP TABLE linz.nz_properties_perspective;
RENAME TABLE linz.nz_properties_perspective_temp TO linz.nz_properties_perspective;

DROP TABLE linz.nz_properties_property_address_reference;
RENAME TABLE linz.nz_properties_property_address_reference_temp TO linz.nz_properties_property_address_reference;

DROP TABLE linz.nz_properties_property_building_reference;
RENAME TABLE linz.nz_properties_property_building_reference_temp TO linz.nz_properties_property_building_reference;

DROP TABLE linz.nz_properties_property_title_reference;
RENAME TABLE linz.nz_properties_property_title_reference_temp TO linz.nz_properties_property_title_reference;

DROP TABLE linz.nz_properties_unit_of_property;
RENAME TABLE linz.nz_properties_unit_of_property_temp TO linz.nz_properties_unit_of_property;

DROP TABLE linz.nz_fence_centrelines_topo_150k;
RENAME TABLE linz.nz_fence_centrelines_topo_150k_temp TO linz.nz_fence_centrelines_topo_150k;

DROP TABLE linz.nz_road_centrelines_topo_150k;
RENAME TABLE linz.nz_road_centrelines_topo_150k_temp TO linz.nz_road_centrelines_topo_150k;

DROP TABLE linz.nz_track_centrelines_topo_150k;
RENAME TABLE linz.nz_track_centrelines_topo_150k_temp TO linz.nz_track_centrelines_topo_150k;

#############################################

