#!/bin/bash
### zip.sh ###
# zip to python zip application

# Local variables
# /home/Development/PythonProjects/linz_schema_loader/Distribute/linz_schema_loader.pyz

python='/usr/bin/python3.13'
python3='/usr/bin/python3.13'
pip='/usr/bin/pip3.13'
pip3='/usr/bin/pip3.13'

clear
cd ..
BASE="$(pwd)"
APP="${BASE##*/}"
ARCHIVE="$BASE/Distribute/$APP.zip"
PLUGIN="/home/Grant/.local/share/QGIS/QGIS3/profiles/default/python/plugins"
PYEXE="$BASE/$APP.pyz"
echo Generate python app $APP from $BASE
$python -V
$pip -V
#
genui () {
# Generate python file from Qt Designer ui file
    echo process $1.ui
    cd $BASE/forms
    rm -fv "$1.py"
    pyuic6 -xo "$1.py" "$1.ui"
    rm -fv "../ui_$1.py"
    cat "Qt_imports.py" "$1.py" | grep -Ev '^from .' > "../ui_$1.py"
    sed -i "s/QtGui.//g; s/QtWidgets.//g; s/QtCore.//g" "../ui_$1.py"
    echo created ui_$1.py
    cd $BASE
} 

echo Create py files from ui definitions
for file in $BASE/forms/*.ui; do
    [ -e "$file" ] || continue
    filename=$(basename -- "$file")
    filename="${filename%.*}"
    genui "$filename"
done

echo Create archive "$ARCHIVE" for app executable
cd $BASE
rm -fv "$ARCHIVE"
rm -fv "$PYEXE"
zip -rv -x="./forms/*" -x="./private/*" -x="./Distribute/*" -x="./__pycache__/*" -x="./dist/*" -x="./nbproject/*" -x="./tests/*" -x="./.*/*" -x=".*" -x="./*.log" -UN=UTF8 "$ARCHIVE" .
echo Create Python executable "$ARCHIVE"
echo '#!/usr/bin/env python' | cat - "$ARCHIVE" > "$PYEXE"
chmod +x "$PYEXE"
echo "$PYEXE"

echo Create archive "$ARCHIVE" for qgis plugin
cd ..
rm -fv "$ARCHIVE"
zip -rv -x="$APP/private/*" -x="$APP/Distribute/*" -x="$APP/__pycache__/*" -x="$APP/dist/*" -x="$APP/nbproject/*" -x="$APP/tests/*" -x="$APP/.*/*" -x="$APP/.*" -x="$APP/*.log" -UN=UTF8 "$ARCHIVE" $APP
echo Extract archive to QGIS plugin folder
unzip -uo "$ARCHIVE" -d $PLUGIN

export PYEXE="/home/Development/PythonProjects/linz_schema_loader/linz_schema_loader.pyz"
echo Run Python executable
echo "$PYEXE"
savePATH=$PATH
savePYTHONPATH=$PYTHONPATH
export savePATH=$PATH
export savePYTHONPATH=$PYTHONPATH
# PATH=/usr/bin:$PATH
# PYTHONPATH=/usr/share/qgis/python:$PYTHONPATH
# QT_PLUGIN_PATH=/usr/lib64/qt5/plugins
PATH=/opt/qgis_3_44_11/bin:$PATH
PYTHONPATH=/opt/qgis_3_44_11/python:$PYTHONPATH
QT_PLUGIN_PATH=/usr/lib64/qt6/plugins
export PATH=$PATH
export PYTHONPATH=$PYTHONPATH
export QT_PLUGIN_PATH=$QT_PLUGIN_PATH
export QT_QPA_PLATFORM=
"$PYEXE"
export PYTHONPATH=$savePYTHONPATH
export PATH=$savePATH
