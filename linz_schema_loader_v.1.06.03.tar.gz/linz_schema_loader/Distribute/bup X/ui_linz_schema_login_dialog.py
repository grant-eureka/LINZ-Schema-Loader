# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'linz_schema_login_dialogZjAFlQ.ui'
##
## Created by: Qt User Interface Compiler version 6.9.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QDialog, QFormLayout, QGridLayout,
    QLabel, QLayout, QLineEdit, QPushButton,
    QSizePolicy, QSpacerItem, QWidget)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        if not Dialog.objectName():
            Dialog.setObjectName(u"Dialog")
        Dialog.setWindowModality(Qt.WindowModality.ApplicationModal)
        Dialog.resize(540, 290)
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(Dialog.sizePolicy().hasHeightForWidth())
        Dialog.setSizePolicy(sizePolicy)
        Dialog.setMinimumSize(QSize(540, 290))
        Dialog.setMaximumSize(QSize(540, 290))
        Dialog.setBaseSize(QSize(540, 290))
        Dialog.setStyleSheet(u"background-color: rgb(224, 255, 225);\n"
"color: rgb(0, 0, 0);")
        self.formLayoutWidget = QWidget(Dialog)
        self.formLayoutWidget.setObjectName(u"formLayoutWidget")
        self.formLayoutWidget.setGeometry(QRect(0, 0, 541, 278))
        self.formLayout = QFormLayout(self.formLayoutWidget)
        self.formLayout.setObjectName(u"formLayout")
        self.formLayout.setSizeConstraint(QLayout.SizeConstraint.SetMinAndMaxSize)
        self.formLayout.setHorizontalSpacing(5)
        self.formLayout.setVerticalSpacing(5)
        self.formLayout.setContentsMargins(5, 5, 5, 0)
        self.hostLabel = QLabel(self.formLayoutWidget)
        self.hostLabel.setObjectName(u"hostLabel")
        sizePolicy.setHeightForWidth(self.hostLabel.sizePolicy().hasHeightForWidth())
        self.hostLabel.setSizePolicy(sizePolicy)
        self.hostLabel.setMinimumSize(QSize(65, 32))
        self.hostLabel.setMaximumSize(QSize(65, 32))
        self.hostLabel.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.formLayout.setWidget(0, QFormLayout.ItemRole.LabelRole, self.hostLabel)

        self.hostField = QLineEdit(self.formLayoutWidget)
        self.hostField.setObjectName(u"hostField")
        self.hostField.setMinimumSize(QSize(0, 32))
        self.hostField.setMaximumSize(QSize(16777215, 32))
        self.hostField.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);")

        self.formLayout.setWidget(0, QFormLayout.ItemRole.FieldRole, self.hostField)

        self.portLabel = QLabel(self.formLayoutWidget)
        self.portLabel.setObjectName(u"portLabel")
        self.portLabel.setMinimumSize(QSize(65, 32))
        self.portLabel.setMaximumSize(QSize(65, 32))
        self.portLabel.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.formLayout.setWidget(1, QFormLayout.ItemRole.LabelRole, self.portLabel)

        self.portField = QLineEdit(self.formLayoutWidget)
        self.portField.setObjectName(u"portField")
        self.portField.setMinimumSize(QSize(0, 32))
        self.portField.setMaximumSize(QSize(16777215, 32))
        self.portField.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);")

        self.formLayout.setWidget(1, QFormLayout.ItemRole.FieldRole, self.portField)

        self.schemaLabel = QLabel(self.formLayoutWidget)
        self.schemaLabel.setObjectName(u"schemaLabel")
        self.schemaLabel.setMinimumSize(QSize(65, 32))
        self.schemaLabel.setMaximumSize(QSize(16777215, 32))
        self.schemaLabel.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.formLayout.setWidget(2, QFormLayout.ItemRole.LabelRole, self.schemaLabel)

        self.schemaField = QLineEdit(self.formLayoutWidget)
        self.schemaField.setObjectName(u"schemaField")
        self.schemaField.setMinimumSize(QSize(0, 32))
        self.schemaField.setMaximumSize(QSize(16777215, 32))
        self.schemaField.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);")

        self.formLayout.setWidget(2, QFormLayout.ItemRole.FieldRole, self.schemaField)

        self.usernameLabel = QLabel(self.formLayoutWidget)
        self.usernameLabel.setObjectName(u"usernameLabel")
        self.usernameLabel.setMinimumSize(QSize(65, 32))
        self.usernameLabel.setMaximumSize(QSize(16777215, 32))
        self.usernameLabel.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.formLayout.setWidget(3, QFormLayout.ItemRole.LabelRole, self.usernameLabel)

        self.usernameField = QLineEdit(self.formLayoutWidget)
        self.usernameField.setObjectName(u"usernameField")
        self.usernameField.setMinimumSize(QSize(0, 32))
        self.usernameField.setMaximumSize(QSize(16777215, 32))
        self.usernameField.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);")

        self.formLayout.setWidget(3, QFormLayout.ItemRole.FieldRole, self.usernameField)

        self.passwordLabel = QLabel(self.formLayoutWidget)
        self.passwordLabel.setObjectName(u"passwordLabel")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        sizePolicy1.setHorizontalStretch(1)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.passwordLabel.sizePolicy().hasHeightForWidth())
        self.passwordLabel.setSizePolicy(sizePolicy1)
        self.passwordLabel.setMinimumSize(QSize(65, 32))
        self.passwordLabel.setMaximumSize(QSize(65, 32))
        self.passwordLabel.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.formLayout.setWidget(4, QFormLayout.ItemRole.LabelRole, self.passwordLabel)

        self.passwordField = QLineEdit(self.formLayoutWidget)
        self.passwordField.setObjectName(u"passwordField")
        self.passwordField.setMinimumSize(QSize(0, 32))
        self.passwordField.setMaximumSize(QSize(16777215, 32))
        self.passwordField.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);")
        self.passwordField.setEchoMode(QLineEdit.EchoMode.Password)

        self.formLayout.setWidget(4, QFormLayout.ItemRole.FieldRole, self.passwordField)

        self.gridLayout_3 = QGridLayout()
        self.gridLayout_3.setObjectName(u"gridLayout_3")
        self.gridLayout_3.setHorizontalSpacing(5)
        self.gridLayout_3.setVerticalSpacing(0)
        self.gridLayout_3.setContentsMargins(5, 0, 5, 0)
        self.verticalSpacer = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_3.addItem(self.verticalSpacer, 0, 1, 1, 1)

        self.horizontalSpacer = QSpacerItem(20, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.gridLayout_3.addItem(self.horizontalSpacer, 1, 0, 1, 1)

        self.okButton = QPushButton(self.formLayoutWidget)
        self.okButton.setObjectName(u"okButton")
        sizePolicy.setHeightForWidth(self.okButton.sizePolicy().hasHeightForWidth())
        self.okButton.setSizePolicy(sizePolicy)
        self.okButton.setMinimumSize(QSize(90, 34))
        self.okButton.setMaximumSize(QSize(90, 34))
        self.okButton.setBaseSize(QSize(0, 34))
        self.okButton.setAutoDefault(False)
        self.okButton.setFlat(False)

        self.gridLayout_3.addWidget(self.okButton, 1, 1, 1, 1)

        self.cancelButton = QPushButton(self.formLayoutWidget)
        self.cancelButton.setObjectName(u"cancelButton")
        sizePolicy.setHeightForWidth(self.cancelButton.sizePolicy().hasHeightForWidth())
        self.cancelButton.setSizePolicy(sizePolicy)
        self.cancelButton.setMinimumSize(QSize(90, 34))
        self.cancelButton.setMaximumSize(QSize(90, 34))
        self.cancelButton.setAutoDefault(False)

        self.gridLayout_3.addWidget(self.cancelButton, 1, 2, 1, 1)


        self.formLayout.setLayout(5, QFormLayout.ItemRole.FieldRole, self.gridLayout_3)


        self.retranslateUi(Dialog)

        self.okButton.setDefault(True)


        QMetaObject.connectSlotsByName(Dialog)
    # setupUi

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(QCoreApplication.translate("Dialog", u"LINZ Schema Login", None))
        self.hostLabel.setText(QCoreApplication.translate("Dialog", u"Host:", None))
        self.portLabel.setText(QCoreApplication.translate("Dialog", u"Port:", None))
        self.schemaLabel.setText(QCoreApplication.translate("Dialog", u"Schema:", None))
        self.usernameLabel.setText(QCoreApplication.translate("Dialog", u"Username:", None))
        self.passwordLabel.setText(QCoreApplication.translate("Dialog", u"Password:", None))
        self.okButton.setText(QCoreApplication.translate("Dialog", u"OK", None))
        self.cancelButton.setText(QCoreApplication.translate("Dialog", u"Cancel", None))
    # retranslateUi

