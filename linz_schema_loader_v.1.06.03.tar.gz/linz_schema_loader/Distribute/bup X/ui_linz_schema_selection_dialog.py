# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'linz_schema_selection_dialogOKnvut.ui'
##
## Created by: Qt User Interface Compiler version 6.9.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QDialog, QGridLayout,
    QLabel, QListWidget, QListWidgetItem, QPushButton,
    QSizePolicy, QSpacerItem, QWidget)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        if not Dialog.objectName():
            Dialog.setObjectName(u"Dialog")
        Dialog.setWindowModality(Qt.WindowModality.ApplicationModal)
        Dialog.resize(400, 250)
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(Dialog.sizePolicy().hasHeightForWidth())
        Dialog.setSizePolicy(sizePolicy)
        Dialog.setMinimumSize(QSize(400, 250))
        Dialog.setMaximumSize(QSize(400, 250))
        Dialog.setStyleSheet(u"background-color: rgb(224, 255, 225);\n"
"color: rgb(0, 0, 0);")
        self.schemaList = QListWidget(Dialog)
        self.schemaList.setObjectName(u"schemaList")
        self.schemaList.setGeometry(QRect(6, 36, 388, 131))
        self.schemaList.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);")
        self.schemaList.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.schemaList.setProperty(u"showDropIndicator", False)
        self.schemaList.setDefaultDropAction(Qt.DropAction.IgnoreAction)
        self.schemaList.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.gridLayoutWidget = QWidget(Dialog)
        self.gridLayoutWidget.setObjectName(u"gridLayoutWidget")
        self.gridLayoutWidget.setGeometry(QRect(10, 170, 381, 71))
        self.gridLayout = QGridLayout(self.gridLayoutWidget)
        self.gridLayout.setObjectName(u"gridLayout")
        self.gridLayout.setHorizontalSpacing(5)
        self.gridLayout.setVerticalSpacing(0)
        self.gridLayout.setContentsMargins(5, 0, 5, 0)
        self.horizontalSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.gridLayout.addItem(self.horizontalSpacer, 2, 0, 1, 1)

        self.okButton = QPushButton(self.gridLayoutWidget)
        self.okButton.setObjectName(u"okButton")
        sizePolicy.setHeightForWidth(self.okButton.sizePolicy().hasHeightForWidth())
        self.okButton.setSizePolicy(sizePolicy)
        self.okButton.setMinimumSize(QSize(90, 34))
        self.okButton.setMaximumSize(QSize(90, 34))
        self.okButton.setBaseSize(QSize(0, 34))
        self.okButton.setAutoDefault(False)
        self.okButton.setFlat(False)

        self.gridLayout.addWidget(self.okButton, 2, 1, 1, 1)

        self.cancelButton = QPushButton(self.gridLayoutWidget)
        self.cancelButton.setObjectName(u"cancelButton")
        sizePolicy.setHeightForWidth(self.cancelButton.sizePolicy().hasHeightForWidth())
        self.cancelButton.setSizePolicy(sizePolicy)
        self.cancelButton.setMinimumSize(QSize(90, 34))
        self.cancelButton.setMaximumSize(QSize(90, 34))
        self.cancelButton.setAutoDefault(False)

        self.gridLayout.addWidget(self.cancelButton, 2, 2, 1, 1)

        self.verticalSpacer = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout.addItem(self.verticalSpacer, 0, 1, 1, 1)

        self.schemaLabel = QLabel(Dialog)
        self.schemaLabel.setObjectName(u"schemaLabel")
        self.schemaLabel.setGeometry(QRect(10, 10, 58, 18))

        self.retranslateUi(Dialog)

        self.okButton.setDefault(True)


        QMetaObject.connectSlotsByName(Dialog)
    # setupUi

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(QCoreApplication.translate("Dialog", u"GIS Schema Selection", None))
        self.okButton.setText(QCoreApplication.translate("Dialog", u"OK", None))
        self.cancelButton.setText(QCoreApplication.translate("Dialog", u"Cancel", None))
        self.schemaLabel.setText(QCoreApplication.translate("Dialog", u"Schemas:", None))
    # retranslateUi

